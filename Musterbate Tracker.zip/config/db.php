<?php
$conn = mysqli_connect("localhost","root","","tracker");
if(!$conn){
  die("Database Connection Failed");
}

/* session sirf tab start ho jab active na ho */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
